import React, { Component, Fragment } from "react";
import "./index.scss";

class BackTop extends Component {
  render() {
    return (
      <Fragment>
        <BackTop />
        <strong style={{ color: "rgba(64, 64, 64, 0.6)" }}> gray </strong>
        button.
      </Fragment>
    );
  }
}
export default BackTop;
